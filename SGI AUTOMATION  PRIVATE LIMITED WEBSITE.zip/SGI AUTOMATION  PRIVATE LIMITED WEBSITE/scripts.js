// Array of product details
const products = [
    {
        img: 'path/to/product1.jpg',
        title: 'Product 1',
        desc: 'Detailed description of Product 1...'
    },
    {
        img: 'path/to/product2.jpg',
        title: 'Product 2',
        desc: 'Detailed description of Product 2...'
    },
    {
        img: 'path/to/product3.jpg',
        title: 'Product 3',
        desc: 'Detailed description of Product 3...'
    },
    {
        img: 'path/to/product4.jpg',
        title: 'Product 4',
        desc: 'Detailed description of Product 4...'
    },
    {
        img: 'path/to/product5.jpg',
        title: 'Product 5',
        desc: 'Detailed description of Product 5...'
    }
    // Add more product details here if needed
];

function openModal(index) {
    // Get the modal
    var modal = document.getElementById("productModal");

    // Get the modal content elements
    var modalImg = document.getElementById("modalImg");
    var modalTitle = document.getElementById("modalTitle");
    var modalDesc = document.getElementById("modalDesc");

    // Set the modal content
    modalImg.src = products[index - 1].img;
    modalTitle.innerText = products[index - 1].title;
    modalDesc.innerText = products[index - 1].desc;

    // Display the modal
    modal.style.display = "block";
}

function closeModal() {
    // Get the modal
    var modal = document.getElementById("productModal");

    // Hide the modal
    modal.style.display = "none";
}
