// Get the modal
var modal = document.getElementById("contactModal");

// Get the button that opens the modal
var btn = document.getElementById("contactButton");

// Get the <span> element that closes the modal
var span = document.getElementById("closeModal");

// Get the success message element
var successMessage = document.getElementById("successMessage");

// When the user clicks the button, open the modal
btn.onclick = function(event) {
    event.preventDefault();
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

// Handle form submission
function submitContactForm(event) {
    event.preventDefault();

    var form = document.getElementById('contactForm');
    var formData = new FormData(form);

    fetch("https://formspree.io/f/xwpeoaka", {
            method: "POST",
            headers: {
                'Accept': 'application/json'
            },
            body: formData
        })
        .then(response => {
            if (response.ok) {
                // Show success message
                successMessage.style.display = "block";
                successMessage.classList.add("show");
                setTimeout(() => {
                    successMessage.classList.remove("show");
                    successMessage.style.display = "none";
                }, 5000); // Hide after 5 seconds

                // Close the modal
                modal.style.display = "none";

                // Reset the form
                form.reset();
            } else {
                response.json().then(data => {
                    if (Object.hasOwn(data, 'errors')) {
                        alert(data["errors"].map(error => error["message"]).join(", "));
                    } else {
                        alert("Oops! There was a problem submitting your form");
                    }
                });
            }
        })
        .catch(error => {
            alert("There was a problem submitting the form. Please try again later.");
        });

    return false; // Prevent default form submission
}

// Attach form submission handler to the form
document.getElementById('contactForm').addEventListener('submit', submitContactForm);